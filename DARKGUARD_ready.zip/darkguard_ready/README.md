# 🛡️ DARKGUARD

**AI-powered Dark Pattern Detector**

DARKGUARD is a Streamlit machine-learning prototype that analyzes website text and predicts whether it contains a dark pattern.

## Problem
Online platforms sometimes use wording that creates artificial pressure or nudges users toward a decision. Examples include fake urgency, scarcity, and social proof.

## What the prototype does
A user pastes website text and DARKGUARD returns:
- Dark Pattern / Not Dark Pattern
- Model confidence
- Top TF-IDF features that influenced the prediction
- A separate quick scan for urgency, scarcity, and social-proof signals
- Basic model and dataset insights

## ML Pipeline
```text
Website Text → Basic Text Cleaning → TF-IDF → Logistic Regression → Prediction
```

## Baseline
- 80/20 stratified train/test split
- TF-IDF with 1- and 2-word features
- Logistic Regression
- Approximately 93.4% test accuracy on the current split

## Tech Stack
Python, Pandas, NumPy, scikit-learn, TF-IDF, Logistic Regression, Streamlit

## Dataset
The dataset contains website snippets with a binary label and a pattern category.

Source: https://github.com/yamanalab/ec-darkpattern

## Run locally
```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Contribution Areas
Open GitHub Issues contain the competition challenges:
- Improve baseline accuracy
- Reduce false negatives
- Improve short-text classification
- Add multi-category detection
- Improve phrase-level explanations

## Project Structure
```text
app.py
model.py
dataset.tsv
requirements.txt
CONTRIBUTING.md
PRESENTATION.md
LICENSE
.gitignore
tests/
└── test_model.py
```

## Note
A model prediction is an indicator produced from the training data; it is not proof of intent, deception, or harm by a website.
